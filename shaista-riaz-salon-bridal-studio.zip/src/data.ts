import { ServiceCard, Testimonial, FAQItem } from "./types";

export const CORE_SERVICES: ServiceCard[] = [
  {
    id: "bridal",
    title: "Signature Bridal Makeup",
    description: "Our signature luxury bridal makeover designed to make your dream look a stunning reality. Flawless HD/Airbrush finish customized for your facial structure.",
    price: "PKR 75,000",
    duration: "4 - 5 Hours",
    imageUrl: "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=800&q=80",
    highlights: [
      "HD / Airbrush High-End Makeup",
      "Premium Eyelashes & Brow styling",
      "Dupatta Setting & Jewelry Draping",
      "Pre-makeup calming hydro-gel therapy",
      "Dior & Charlotte Tilbury products only"
    ]
  },
  {
    id: "party",
    title: "Glamour Party Makeover",
    description: "From soft, luminous glam to bold luxury evening makeovers. Perfect for receptions, shendis, or high-end formal gatherings.",
    price: "PKR 18,000",
    duration: "1.5 Hours",
    imageUrl: "https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?auto=format&fit=crop&w=800&q=80",
    highlights: [
      "Customized skin prep & flawless base",
      "Bespoke dramatic or elegant eye art",
      "High-fashion contour & custom glow lip",
      "Premium quality lash extensions included",
      "Long-lasting 16-hour setting spray locks"
    ]
  },
  {
    id: "hair",
    title: "Couture Hair Styling & Therapy",
    description: "Hollywood waves, traditional intricate bridal updos, hair dye, or repairing keratin treatments curated by master hair artists.",
    price: "PKR 12,000",
    duration: "1 - 2 Hours",
    imageUrl: "https://images.unsplash.com/photo-1562322140-8baeececf3df?auto=format&fit=crop&w=800&q=80",
    highlights: [
      "Intricate braids, buns or signature curls",
      "Premium hair products used (L'Oreal, Olaplex)",
      "Vapor thermal hair protection shield",
      "Hair extension padding & placement service",
      "Silk protein finish for ultimate shine"
    ]
  },
  {
    id: "aesthetics",
    title: "Aesthetics & Medical Glow Facials",
    description: "Unlock immediate radiance with deep exfoliating luxury therapies, specialized micro-current firming, and premium hydration.",
    price: "PKR 15,000",
    duration: "1 Hour",
    imageUrl: "https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?auto=format&fit=crop&w=800&q=80",
    highlights: [
      "Oxygen infused deep-pore cleansing",
      "Premium organic gold or glow mask",
      "Aesthetic face contours & ice globe massage",
      "Hydra-peel extraction & intense hydration boost",
      "Includes calming neck & shoulder acupressure"
    ]
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: "test-1",
    name: "Zainab Chaudhry",
    location: "DHA Phase II, Islamabad",
    rating: 5,
    comment: "Shaista did my bridal makeup and it was absolutely magnificent! I got endless compliments throughout my barat. The makeup survived tears, laughter, and high-intensity studio photography perfectly.",
    service: "Signature Bridal Makeup",
    date: "A week ago"
  },
  {
    id: "test-2",
    name: "Ayesha Jahangir",
    location: "Giga Mall Area, DHA",
    rating: 5,
    comment: "I went for a party makeover for my brother's valima event. Unbelievable eye makeup! The team is so disciplined, the soft champagne shades matched my dupatta completely. Best salon experience in Islamabad.",
    service: "Glamour Party Makeover",
    date: "2 weeks ago"
  },
  {
    id: "test-3",
    name: "Mahnoor Malik",
    location: "Bahria Town Phase 7",
    rating: 5,
    comment: "Highly recommend their Hydra-Glow aesthetic facial. My skin felt extremely soft and radiant right before my engagement. The gold mask massage is absolute heaven. Elegant and super hygienic studio!",
    service: "Aesthetics & Medical Glow Facials",
    date: "Last month"
  }
];

export const FAQs: FAQItem[] = [
  {
    question: "Do you offer on-location or home bridal makeup services?",
    answer: "Yes, we provide luxury on-location bridal makeover services for both Islamabad and Rawalpindi. Please contact our salon desk at least 4 weeks in advance for booking and special home-setup rates."
  },
  {
    question: "Which makeup brands do you use in your bridal studio?",
    answer: "We use exclusively premium, luxurious international cosmetics brands. Our standard kit consists of Dior, Charlotte Tilbury, NARS, Tom Ford, Fenty Beauty, Anastasia Beverly Hills, and Huda Beauty to ensure high photographic quality and skin comfort."
  },
  {
    question: "What is your booking reservation policy?",
    answer: "To secure your slot for bridal or party makeovers, a 50% advance deposit is requested. Bookings can be modified up to 5 days before the event date, subject to availability. You can book directly in our online form!"
  },
  {
    question: "How long before my wedding schedule should I book the bridal appointment?",
    answer: "Due to high traffic during prime wedding seasons (Winters & Spring), we highly advise booking your spot at least 2 to 3 months early. Slots fill up fast especially for weekend slots."
  }
];

export const BUSINESS_INFO = {
  phone: "+92 51 8990395",
  phoneDisplay: "051-8990395",
  address: "Plot 34-B, Sector D, DHA Phase II, Islamabad (Near Giga Mall)",
  hours: "Monday - Sunday: 11:00 AM - 8:00 PM",
  instaLink: "#",
  facebookLink: "#"
};
