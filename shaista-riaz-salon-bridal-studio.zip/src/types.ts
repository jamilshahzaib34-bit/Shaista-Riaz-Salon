export interface ServiceCard {
  id: string;
  title: string;
  description: string;
  price: string;
  duration: string;
  imageUrl: string;
  highlights: string[];
}

export interface Testimonial {
  id: string;
  name: string;
  location: string;
  rating: number;
  comment: string;
  service: string;
  date: string;
}

export interface Booking {
  id: string;
  fullName: string;
  phone: string;
  email: string;
  serviceId: string;
  date: string;
  timeSlot: string;
  specialRequests?: string;
  bookingTime: string;
}

export interface FAQItem {
  question: string;
  answer: string;
}
