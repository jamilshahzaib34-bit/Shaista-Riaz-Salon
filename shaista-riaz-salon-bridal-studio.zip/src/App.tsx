import React, { useState } from "react";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Services from "./components/Services";
import BookingForm from "./components/BookingForm";
import Reviews from "./components/Reviews";
import FaqSection from "./components/FaqSection";
import Footer from "./components/Footer";
import { Sparkles, Calendar, Heart, ShieldCheck, Star } from "lucide-react";

export default function App() {
  const [selectedServiceId, setSelectedServiceId] = useState<string>("bridal");

  const handleSelectService = (serviceId: string) => {
    setSelectedServiceId(serviceId);
    // Smooth scroll down to the luxury booking form
    const elem = document.getElementById("booking-section");
    if (elem) {
      elem.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  const handleBookClick = () => {
    const elem = document.getElementById("booking-section");
    if (elem) {
      elem.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <div id="app-root-frame" className="relative min-h-screen bg-[#FDFBF7] text-[#1E1E1E] font-sans antialiased overflow-x-hidden">
      
      {/* 1. Header & Navigation */}
      <Navbar onBookClick={handleBookClick} />

      {/* 2. Hero Section featuring trust container and the immediate horizontal Info Strip */}
      <Hero onBookClick={handleBookClick} />

      {/* Luxury Welcome/Vibe Statement */}
      <section className="w-full py-16 bg-[#FDFBF7] border-b border-[#D4AF37]/10 text-center px-4">
        <div className="max-w-4xl mx-auto flex flex-col items-center">
          <Heart className="w-6 h-6 text-[#D4AF37] mb-4 animate-pulse stroke-[1.5]" />
          <h3 className="font-serif text-2xl md:text-3xl text-[#1E1E1E] italic tracking-wide max-w-2xl font-light mb-4">
            "True beauty is an intimate glow, cultivated with absolute precision."
          </h3>
          <p className="font-sans text-[11px] uppercase tracking-[0.25em] text-[#D4AF37] font-semibold">
            — SHAISTA RIAZ, Founder & Master Couturier
          </p>
        </div>
      </section>

      {/* 3. Core Services 4-Card Grid on white background and gold Highlights */}
      <Services onSelectService={handleSelectService} />

      {/* 4. Luxury Booking Form with local validation and Local Storage persistence */}
      <BookingForm
        selectedServiceId={selectedServiceId}
        setSelectedServiceId={setSelectedServiceId}
      />

      {/* 5. Trust reviews and rating metrics */}
      <Reviews />

      {/* 6. Accordion Frequently Asked Questions (FAQs) */}
      <FaqSection />

      {/* 7. Footer displaying DHA phase II address, timing, hours and insta links */}
      <Footer />

      {/* Subtle Floating Assist Button (Call/Book) to increase conversions */}
      <div className="fixed bottom-6 right-6 z-40 hidden md:flex items-center gap-2 font-sans">
        <button
          onClick={handleBookClick}
          id="floating-conversion-cta"
          className="flex items-center gap-2 bg-[#D4AF37] hover:bg-[#1E1E1E] text-[#1E1E1E] hover:text-[#FDFBF7] px-5 py-3 shadow-2xl border border-[#D4AF37] hover:border-[#1E1E1E] transition-all duration-300 uppercase tracking-widest text-[10px] font-bold cursor-pointer"
        >
          <Calendar className="w-4 h-4 shrink-0" />
          <span>Book Ritual</span>
        </button>
      </div>

    </div>
  );
}
