import React, { useState, useEffect } from "react";
import { Calendar, Phone, Mail, User, Clock, MessageSquare, CheckCircle2, Trash2, ShieldCheck, Sparkles } from "lucide-react";
import { CORE_SERVICES, BUSINESS_INFO } from "../data";
import { Booking } from "../types";

interface BookingFormProps {
  selectedServiceId: string;
  setSelectedServiceId: (id: string) => void;
}

const TIME_SLOTS = [
  "11:00 AM",
  "12:30 PM",
  "02:00 PM",
  "03:30 PM",
  "05:00 PM",
  "06:30 PM",
  "08:00 PM"
];

export default function BookingForm({ selectedServiceId, setSelectedServiceId }: BookingFormProps) {
  // Client Form Details State
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [bookingDate, setBookingDate] = useState("");
  const [timeSlot, setTimeSlot] = useState("");
  const [specialRequests, setSpecialRequests] = useState("");
  
  // App states
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [lastBookingCreated, setLastBookingCreated] = useState<Booking | null>(null);
  const [savedBookings, setSavedBookings] = useState<Booking[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  // Set min date to today's date
  const getTodayDateString = () => {
    const today = new Date();
    const dd = String(today.getDate()).padStart(2, "0");
    const mm = String(today.getMonth() + 1).padStart(2, "0");
    const yyyy = today.getFullYear();
    return `${yyyy}-${mm}-${dd}`;
  };

  // Load bookings from localStorage
  useEffect(() => {
    try {
      const bookingsJson = localStorage.getItem("shaista_bookings_history");
      if (bookingsJson) {
        setSavedBookings(JSON.parse(bookingsJson));
      }
    } catch (e) {
      console.error("Failed to load bookings from browser storage", e);
    }
  }, []);

  // Submit Booking handler
  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage("");

    // Simple robust validation
    if (!fullName.trim()) {
      setErrorMessage("Please enter your full name.");
      return;
    }
    if (!phone.trim() || phone.trim().length < 10) {
      setErrorMessage("Please enter a valid active phone receipt number.");
      return;
    }
    if (!bookingDate) {
      setErrorMessage("Please pick an appointment date of ritual.");
      return;
    }
    if (!timeSlot) {
      setErrorMessage("Please select your preferred timing window slot.");
      return;
    }

    setIsSubmitting(true);

    // Simulate luxury booking processing with smooth timeouts
    setTimeout(() => {
      const newBooking: Booking = {
        id: `SRB-${Math.floor(100000 + Math.random() * 900000)}`,
        fullName,
        phone,
        email: email || "inquiry@client.com",
        serviceId: selectedServiceId || "bridal",
        date: bookingDate,
        timeSlot,
        specialRequests,
        bookingTime: new Date().toLocaleString()
      };

      try {
        const updatedList = [newBooking, ...savedBookings];
        setSavedBookings(updatedList);
        localStorage.setItem("shaista_bookings_history", JSON.stringify(updatedList));
        setLastBookingCreated(newBooking);

        // Reset inputs
        setFullName("");
        setPhone("");
        setEmail("");
        setBookingDate("");
        setTimeSlot("");
        setSpecialRequests("");
      } catch (err) {
        console.error("Localstorage write error", err);
      } finally {
        setIsSubmitting(false);
      }
    }, 1200);
  };

  // Delete booking from history
  const deleteBooking = (id: string) => {
    const filterBookings = savedBookings.filter((b) => b.id !== id);
    setSavedBookings(filterBookings);
    localStorage.setItem("shaista_bookings_history", JSON.stringify(filterBookings));
    if (lastBookingCreated && lastBookingCreated.id === id) {
      setLastBookingCreated(null);
    }
  };

  const activeServiceObj = CORE_SERVICES.find((s) => s.id === selectedServiceId) || CORE_SERVICES[0];

  return (
    <section id="booking-section" className="w-full py-24 bg-[#F3E8E6] px-4 md:px-8 border-t border-[#D4AF37]/15">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Information & Trust block */}
          <div className="lg:col-span-5 flex flex-col justify-start">
            <span className="font-sans text-[11px] uppercase tracking-[0.25em] text-[#D4AF37] font-semibold block mb-2">
              DHA Islamabad Elite Studio
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl text-[#1E1E1E] tracking-normal mb-6 font-light uppercase">
              RESERVE YOUR <span className="italic font-normal block text-[#D4AF37]">Bridal Ritual</span>
            </h2>
            
            <p className="font-sans text-xs md:text-sm text-[#1E1E1E]/80 font-light leading-relaxed mb-6">
              Fill out the form to request an appointment. Our reservations manager will contact you within 2 hours on your provided phone number to confirm the slot and process your booking advance payment.
            </p>

            {/* Quick Benefits lists */}
            <div className="space-y-4 mb-8">
              <div className="flex items-center gap-3 bg-[#FDFBF7]/60 p-3 border-l-2 border-[#D4AF37]">
                <ShieldCheck className="w-5 h-5 text-[#D4AF37]" />
                <span className="font-sans text-xs text-[#1E1E1E]/95 font-medium">Safe imported products (Olaplex / Huda Beauty)</span>
              </div>
              <div className="flex items-center gap-3 bg-[#FDFBF7]/60 p-3 border-l-2 border-[#D4AF37]">
                <Clock className="w-5 h-5 text-[#D4AF37]" />
                <span className="font-sans text-xs text-[#1E1E1E]/95 font-medium">Strict zero waiting times for confirmed brides</span>
              </div>
              <div className="flex items-center gap-3 bg-[#FDFBF7]/60 p-3 border-l-2 border-[#D4AF37]">
                <Sparkles className="w-5 h-5 text-[#D4AF37]" />
                <span className="font-sans text-xs text-[#1E1E1E]/95 font-medium">Bespoke lighting consultations for barat/valima</span>
              </div>
            </div>

            {/* History drawer trigger if bookings exist */}
            {savedBookings.length > 0 && (
              <div className="border border-[#1E1E1E]/10 p-5 bg-[#FDFBF7]/45 flex flex-col gap-3">
                <div className="flex justify-between items-center">
                  <span className="font-sans text-xs font-semibold text-[#1E1E1E]">Your Saved Bookings ({savedBookings.length})</span>
                  <button 
                    onClick={() => setShowHistory(!showHistory)}
                    className="text-xs font-sans text-[#D4AF37] font-bold hover:underline cursor-pointer"
                  >
                    {showHistory ? "Collapse History" : "View Receipt Detail"}
                  </button>
                </div>

                {showHistory && (
                  <div className="flex flex-col gap-3 max-h-60 overflow-y-auto mt-2">
                    {savedBookings.map((b) => {
                      const svc = CORE_SERVICES.find((s) => s.id === b.serviceId);
                      return (
                        <div key={b.id} className="p-3 bg-[#FDFBF7] border border-[#D4AF37]/20 flex justify-between items-start text-xs font-sans">
                          <div>
                            <p className="font-semibold text-[#1E1E1E]">{b.fullName}</p>
                            <p className="text-[11px] text-[#D4AF37] font-medium">{svc?.title || "Custom Service"}</p>
                            <p className="text-[11px] text-[#1E1E1E]/60">{b.date} • {b.timeSlot}</p>
                            <p className="text-[10px] text-gray-400 font-mono mt-1">{b.id}</p>
                          </div>
                          <button
                            onClick={() => deleteBooking(b.id)}
                            className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-gray-50 transition-all rounded-none cursor-pointer"
                            title="Discard Booking"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Form & Card Column */}
          <div className="lg:col-span-7 w-full bg-[#FDFBF7] p-8 md:p-10 border border-[#D4AF37]/30 shadow-xl">
            {lastBookingCreated ? (
              /* Booking Success State Container */
              <div className="text-center py-8 flex flex-col items-center animate-scaleIn font-sans">
                <CheckCircle2 className="w-16 h-16 text-[#D4AF37] mb-4 stroke-[1.5]" />
                
                <span className="text-[10px] uppercase tracking-widest text-[#D4AF37] font-semibold mb-1">
                  Ritual Requested Successfully
                </span>
                
                <h3 className="font-serif text-3xl tracking-wide text-[#1E1E1E] font-light mb-2">
                  CONFIRMATION PENDING
                </h3>
                
                <p className="text-xs font-sans text-[#1E1E1E]/70 max-w-sm mb-6 leading-relaxed">
                  Excellent, <strong>{lastBookingCreated.fullName}</strong>. We have initialized your luxury reservation record under ID 
                  <strong className="text-sm text-[#1E1E1E] font-mono block tracking-wider mt-1">{lastBookingCreated.id}</strong>
                </p>

                {/* Receipt Card */}
                <div className="w-full bg-[#F3E8E6] text-left p-6 mb-8 border border-[#D4AF37]/20 flex flex-col gap-3">
                  <div className="flex justify-between border-b border-[#1E1E1E]/10 pb-2.5">
                    <span className="text-[10px] uppercase font-bold text-[#1E1E1E]/70">Reserved Package:</span>
                    <span className="text-xs font-semibold text-[#1E1E1E]">{activeServiceObj.title}</span>
                  </div>
                  <div className="flex justify-between border-b border-[#1E1E1E]/10 pb-2.5">
                    <span className="text-[10px] uppercase font-bold text-[#1E1E1E]/70">Selected Time & Date:</span>
                    <span className="text-xs font-semibold text-[#1E1E1E]">{lastBookingCreated.date} at {lastBookingCreated.timeSlot}</span>
                  </div>
                  <div className="flex justify-between border-b border-[#1E1E1E]/10 pb-2.5">
                    <span className="text-[10px] uppercase font-bold text-[#1E1E1E]/70">Primary Contact:</span>
                    <span className="text-xs font-semibold text-[#1E1E1E]">{lastBookingCreated.phone}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[10px] uppercase font-bold text-[#1E1E1E]/70">Package Rate:</span>
                    <span className="text-xs font-bold text-[#D4AF37] font-mono">{activeServiceObj.price}</span>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-4 w-full">
                  <button
                    onClick={() => setLastBookingCreated(null)}
                    className="flex-1 bg-[#1E1E1E] text-[#FDFBF7] hover:bg-[#D4AF37] hover:text-[#1E1E1E] transition-all font-sans text-xs font-bold uppercase tracking-widest py-3.5 cursor-pointer"
                  >
                    Set Another Ritual
                  </button>
                  <a
                    href={`tel:${BUSINESS_INFO.phone}`}
                    className="flex-1 border border-[#D4AF37] text-[#1E1E1E] hover:bg-[#F3E8E6] transition-all font-sans text-xs font-bold uppercase tracking-widest py-3.5 block text-center"
                  >
                    Call Studio Desk
                  </a>
                </div>
              </div>
            ) : (
              /* Active booking form */
              <form onSubmit={handleBookingSubmit} aria-label="Appointment booking form font-sans" className="space-y-6">
                
                {/* Form header message */}
                <div className="border-b border-[#D4AF37]/20 pb-4 mb-4">
                  <h3 className="font-serif text-lg text-[#1E1E1E] tracking-wider uppercase font-medium">
                    Personalized Ritual Form
                  </h3>
                  <p className="text-[11px] text-gray-500 font-sans mt-1">Please fulfill the fields below. Asterisks (*) signify vital inputs.</p>
                </div>

                {errorMessage && (
                  <div className="p-3.5 bg-red-50 border-l-4 border-red-500 text-xs text-red-700 font-sans font-medium" role="alert">
                    {errorMessage}
                  </div>
                )}

                {/* Grid Input */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Full Name Input */}
                  <div className="flex flex-col gap-1.5">
                    <label htmlFor="fullname" className="font-sans text-[11px] uppercase tracking-wider text-[#1E1E1E] font-semibold">
                      Full Name *
                    </label>
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-[#D4AF37]">
                        <User className="w-4 h-4" />
                      </span>
                      <input
                        type="text"
                        id="fullname"
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        placeholder="Zainab Malik"
                        required
                        className="w-full bg-[#1E1E1E]/5 pl-10 pr-4 py-3 text-xs text-[#1E1E1E] border border-transparent focus:border-[#D4AF37] focus:bg-[#FDFBF7] rounded-none shadow-inner"
                      />
                    </div>
                  </div>

                  {/* Phone Input */}
                  <div className="flex flex-col gap-1.5">
                    <label htmlFor="phone" className="font-sans text-[11px] uppercase tracking-wider text-[#1E1E1E] font-semibold">
                      Phone Number *
                    </label>
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-[#D4AF37]">
                        <Phone className="w-4 h-4" />
                      </span>
                      <input
                        type="tel"
                        id="phone"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="e.g., 0321 8990395"
                        required
                        className="w-full bg-[#1E1E1E]/5 pl-10 pr-4 py-3 text-xs text-[#1E1E1E] border border-transparent focus:border-[#D4AF37] focus:bg-[#FDFBF7] rounded-none shadow-inner"
                      />
                    </div>
                  </div>
                </div>

                {/* Email and Service Selection */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Email Input */}
                  <div className="flex flex-col gap-1.5">
                    <label htmlFor="email" className="font-sans text-[11px] uppercase tracking-wider text-[#1E1E1E] font-semibold">
                      Email Address
                    </label>
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-[#D4AF37]">
                        <Mail className="w-4 h-4" />
                      </span>
                      <input
                        type="email"
                        id="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="client@luxury.com"
                        className="w-full bg-[#1E1E1E]/5 pl-10 pr-4 py-3 text-xs text-[#1E1E1E] border border-transparent focus:border-[#D4AF37] focus:bg-[#FDFBF7] rounded-none shadow-inner"
                      />
                    </div>
                  </div>

                  {/* Service Input */}
                  <div className="flex flex-col gap-1.5">
                    <label htmlFor="select-service" className="font-sans text-[11px] uppercase tracking-wider text-[#1E1E1E] font-semibold">
                      Desired Core Service *
                    </label>
                    <select
                      id="select-service"
                      value={selectedServiceId}
                      onChange={(e) => setSelectedServiceId(e.target.value)}
                      required
                      className="w-full bg-[#1E1E1E]/5 px-4 py-3 text-xs text-[#1E1E1E] border border-transparent focus:border-[#D4AF37] focus:bg-[#FDFBF7] rounded-none cursor-pointer h-[42px]"
                    >
                      {CORE_SERVICES.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.title} ({s.price})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Date and Time Selector */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Date Picker */}
                  <div className="flex flex-col gap-1.5">
                    <label htmlFor="booking-date" className="font-sans text-[11px] uppercase tracking-wider text-[#1E1E1E] font-semibold">
                      Appointment Date *
                    </label>
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-[#D4AF37]">
                        <Calendar className="w-4 h-4" />
                      </span>
                      <input
                        type="date"
                        id="booking-date"
                        min={getTodayDateString()}
                        value={bookingDate}
                        onChange={(e) => setBookingDate(e.target.value)}
                        required
                        className="w-full bg-[#1E1E1E]/5 pl-10 pr-4 py-3 text-xs text-[#1E1E1E] border border-transparent focus:border-[#D4AF37] focus:bg-[#FDFBF7] rounded-none cursor-pointer"
                      />
                    </div>
                  </div>

                  {/* Time Slot Selector */}
                  <div className="flex flex-col gap-1.5">
                    <label htmlFor="time-slot" className="font-sans text-[11px] uppercase tracking-wider text-[#1E1E1E] font-semibold">
                      Preferred Time Slot *
                    </label>
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-[#D4AF37]">
                        <Clock className="w-4 h-4" />
                      </span>
                      <select
                        id="time-slot"
                        value={timeSlot}
                        onChange={(e) => setTimeSlot(e.target.value)}
                        required
                        className="w-full bg-[#1E1E1E]/5 pl-10 pr-4 py-3 text-xs text-[#1E1E1E] border border-transparent focus:border-[#D4AF37] focus:bg-[#FDFBF7] rounded-none cursor-pointer h-[42px]"
                      >
                        <option value="">-- Choose Slot --</option>
                        {TIME_SLOTS.map((slot) => (
                          <option key={slot} value={slot}>
                            {slot}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>

                {/* Special Request */}
                <div className="flex flex-col gap-1.5">
                  <label htmlFor="requests" className="font-sans text-[11px] uppercase tracking-wider text-[#1E1E1E] font-semibold">
                    Special Inquiries & Preparation Notes
                  </label>
                  <div className="relative">
                    <span className="absolute top-3 left-0 flex items-start pl-3 text-[#D4AF37]">
                      <MessageSquare className="w-4 h-4" />
                    </span>
                    <textarea
                      id="requests"
                      rows={3}
                      value={specialRequests}
                      onChange={(e) => setSpecialRequests(e.target.value)}
                      placeholder="e.g., Any skin allergies, specific theme wishes, jewelry draping requirements, or travel assistance..."
                      className="w-full bg-[#1E1E1E]/5 pl-10 pr-4 py-3 text-xs text-[#1E1E1E] border border-transparent focus:border-[#D4AF37] focus:bg-[#FDFBF7] rounded-none shadow-inner"
                    ></textarea>
                  </div>
                </div>

                {/* Pricing Disclaimer */}
                <div className="bg-[#1E1E1E]/5 p-4 text-[11px] text-[#1E1E1E]/70 font-sans leading-relaxed">
                  * Note: Signature bridal makeup packages require a 50% advance token bank transfer to reserve. Standard appointment slots are soft reserved for <strong>48 hours</strong> pending token verification.
                </div>

                {/* Submit button: High-contrast gold "Book Now" */}
                <button
                  type="submit"
                  disabled={isSubmitting}
                  id="submit-booking-btn"
                  className="w-full flex items-center justify-center gap-2 bg-[#D4AF37] hover:bg-[#1E1E1E] text-[#1E1E1E] hover:text-[#FDFBF7] py-4 text-xs font-bold uppercase tracking-[0.25em] transition-all duration-300 border border-[#D4AF37] hover:border-[#1E1E1E] cursor-pointer"
                >
                  {isSubmitting ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-2 border-[#1E1E1E] border-t-transparent"></div>
                      <span>Locking Premium Slot...</span>
                    </>
                  ) : (
                    <>
                      <span>Lock Booking Ritual Now</span>
                    </>
                  )}
                </button>
              </form>
            )}
          </div>

        </div>
      </div>
    </section>
  );
}
