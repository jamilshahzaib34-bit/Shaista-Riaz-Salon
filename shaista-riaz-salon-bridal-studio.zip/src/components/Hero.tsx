import React from "react";
import { Star, Phone, Clock, ArrowRight } from "lucide-react";
import { BUSINESS_INFO } from "../data";

interface HeroProps {
  onBookClick: () => void;
}

export default function Hero({ onBookClick }: HeroProps) {
  return (
    <header className="relative w-full">
      {/* Immersive Elegant Hero Frame */}
      <div className="relative min-h-[85vh] flex items-center justify-center bg-[#1E1E1E] text-[#FDFBF7] overflow-hidden py-16 md:py-24">
        {/* Elegant parallax-style image background with a heavy glamorous dark overlay */}
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&w=1920&q=85"
            alt="Shaista Riaz Luxury Studio Interior"
            className="w-full h-full object-cover object-center opacity-40 scale-105 animate-subtlePulse"
            referrerPolicy="no-referrer"
          />
          {/* Subtle gold-infused gradient overlay to match exact palette */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#1E1E1E] via-[#1E1E1E]/80 to-[#1E1E1E]/50"></div>
        </div>

        {/* Content Container */}
        <div className="relative z-10 max-w-5xl mx-auto px-4 text-center flex flex-col items-center">
          {/* Trust Badge: Gold-bordered container featuring DHA rating */}
          <div
            id="trust-badge-container"
            className="mb-6 inline-flex items-center gap-2 bg-[#FDFBF7]/5 backdrop-blur-sm border border-[#D4AF37] px-4 py-2 rounded-none animate-fadeInUp"
          >
            <div className="flex items-center text-[#D4AF37]">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-3.5 h-3.5 fill-current" />
              ))}
            </div>
            <span className="font-sans text-[10px] md:text-xs uppercase tracking-[0.2em] text-[#FDFBF7] font-semibold">
              ★ 4.7/5 Stars Rated by DHA Clients
            </span>
          </div>

          {/* Luxury Serif Main Heading */}
          <blockquote className="font-serif text-[#D4AF37] text-lg md:text-xl italic tracking-wide mb-3">
            Now Open in DHA Islamabad
          </blockquote>
          
          <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-light tracking-wide text-[#FDFBF7] uppercase leading-tight max-w-4xl mb-6">
            The Epitome of <span className="italic block mt-1 text-[#D4AF37] font-normal font-serif">Bridal Perfection</span>
          </h2>

          <p className="font-sans text-sm sm:text-base md:text-lg text-[#FDFBF7]/80 font-light tracking-wide max-w-2xl mb-10 leading-relaxed">
            Unveiling signature glow makeovers, luxury micro-contouring, and custom hairstyles curated specifically for DHA’s premium brides.
          </p>

          {/* CTA: Bold Gold Call to Action Button with smooth scaling hover effect */}
          <button
            onClick={onBookClick}
            id="hero-reserve-btn"
            className="group relative inline-flex items-center gap-3 bg-[#D4AF37] text-[#1E1E1E] px-8 py-4 sm:px-10 sm:py-5 font-sans font-bold text-xs uppercase tracking-[0.25em] shadow-2xl transition-all duration-500 ease-out hover:scale-105 hover:bg-[#FDFBF7] hover:text-[#1E1E1E] border border-[#D4AF37] cursor-pointer"
          >
            Schedule Bridal Ritual
            <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1.5" />
          </button>
        </div>
      </div>

      {/* INFO STRIP: Distinct horizontal bar showcasing hours & phone number */}
      <div
        id="luxury-info-strip"
        className="relative z-20 w-full bg-[#1E1E1E] border-y border-[#D4AF37]/30 py-6 px-4 shadow-xl"
      >
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-[#D4AF37]/20 items-center gap-6 md:gap-0 text-center">
          
          {/* Hour display */}
          <div className="flex flex-col items-center justify-center py-2 md:py-0 md:px-6">
            <span className="font-serif text-[#D4AF37] text-xs uppercase tracking-widest mb-1.5 flex items-center gap-1.5 font-bold">
              <Clock className="w-3.5 h-3.5" /> Timings
            </span>
            <span className="font-sans text-xs md:text-sm text-[#FDFBF7]/90 font-medium">
              {BUSINESS_INFO.hours}
            </span>
          </div>

          {/* Quick Phone Call */}
          <div className="flex flex-col items-center justify-center py-4 md:py-0 md:px-6">
            <span className="font-serif text-[#D4AF37] text-xs uppercase tracking-widest mb-1.5 flex items-center gap-1.5 font-bold">
              <Phone className="w-3.5 h-3.5" /> Phone Reservation
            </span>
            <a
              href={`tel:${BUSINESS_INFO.phone}`}
              className="font-sans text-lg md:text-xl text-[#FDFBF7] font-semibold tracking-wider hover:text-[#D4AF37] transition-all"
            >
              {BUSINESS_INFO.phoneDisplay}
            </a>
          </div>

          {/* DHA Address details */}
          <div className="flex flex-col items-center justify-center py-2 md:py-0 md:px-6">
            <span className="font-serif text-[#D4AF37] text-xs uppercase tracking-widest mb-1.5 font-bold">
              Bridal Studio Address
            </span>
            <span className="font-sans text-xs text-[#FDFBF7]/90 leading-relaxed max-w-xs font-medium">
              {BUSINESS_INFO.address}
            </span>
          </div>

        </div>
      </div>
    </header>
  );
}
