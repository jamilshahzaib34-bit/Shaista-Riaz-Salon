import React from "react";
import { Star, Quote, Heart, Award, ShieldAlert, Sparkles } from "lucide-react";
import { TESTIMONIALS } from "../data";

export default function Reviews() {
  return (
    <section id="reviews" className="w-full py-24 bg-[#F3E8E6] px-4 md:px-8">
      <div className="max-w-7xl mx-auto">
        
        {/* Header Block */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-8">
          <div>
            <span className="font-sans text-[11px] uppercase tracking-[0.25em] text-[#D4AF37] font-semibold block mb-3">
              CLIENT TESTIMONIALS & STATS
            </span>
            <h2 className="font-serif text-3xl md:text-5xl text-[#1E1E1E] tracking-wide font-light uppercase">
              REVIEWS & <span className="italic font-normal block text-[#D4AF37]">Accolades</span>
            </h2>
            <div className="h-[2px] w-24 bg-[#D4AF37] mt-6"></div>
          </div>
          <div className="flex items-center gap-4 bg-[#FDFBF7] p-5 border border-[#D4AF37]/20 shadow-md max-w-sm">
            <div className="bg-[#D4AF37]/10 p-3 rounded-none shrink-0 text-[#D4AF37]">
              <Award className="w-8 h-8" />
            </div>
            <div>
              <p className="font-serif text-2xl text-[#1E1E1E] font-bold">★ 4.7 / 5.0</p>
              <p className="font-sans text-[11px] uppercase tracking-wider text-gray-500 font-medium">Rated by 200+ DHA Clients</p>
            </div>
          </div>
        </div>

        {/* Testimonials 3-Card Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {TESTIMONIALS.map((t) => (
            <div
              key={t.id}
              className="bg-[#FDFBF7] p-8 border border-gray-100 flex flex-col justify-between shadow-sm relative group hover:border-[#D4AF37]/60 hover:shadow-lg transition-all duration-300"
            >
              {/* Quotes icon highlight background */}
              <Quote className="absolute top-6 right-8 w-12 h-12 text-[#D4AF37]/10 pointer-events-none group-hover:scale-110 transition-transform duration-300" />

              <div>
                {/* Rating stars */}
                <div className="flex items-center text-[#D4AF37] mb-4">
                  {[...Array(t.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-current" />
                  ))}
                </div>

                {/* Comment */}
                <blockquote className="font-sans text-xs md:text-sm text-[#1E1E1E]/80 leading-relaxed font-light mb-6 block italic">
                  "{t.comment}"
                </blockquote>
              </div>

              <div>
                <div className="h-[1px] w-full bg-gray-100 mb-4"></div>
                {/* Author Info */}
                <div className="flex justify-between items-center">
                  <div>
                    <h4 className="font-serif text-sm font-bold text-[#1E1E1E]">
                      {t.name}
                    </h4>
                    <p className="font-sans text-[9px] uppercase tracking-widest text-[#D4AF37] font-medium mt-0.5">
                      {t.location}
                    </p>
                  </div>
                  <span className="font-sans text-[10px] text-gray-400">
                    {t.date}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Visual Cosmetics Brand bar */}
        <div className="mt-20 border-t border-[#D4AF37]/20 pt-12">
          <p className="font-sans text-[10px] uppercase tracking-[0.25em] text-[#1E1E1E]/60 text-center mb-8 font-semibold">
            EXCLUSIVELY CRAFTED WITH PREMIUM LUXURY BRANDS
          </p>
          <div className="flex flex-wrap justify-center items-center gap-8 md:gap-16 opacity-40 grayscale contrast-120">
            {/* Elegant text representations of major luxury brands since icons are not requested */}
            <span className="font-serif text-lg tracking-[0.2em] font-light text-[#1E1E1E] uppercase">CHANEL</span>
            <span className="font-serif text-lg tracking-[0.2em] font-light text-[#1E1E1E] uppercase">DIOR</span>
            <span className="font-serif text-lg tracking-[0.2em] font-light text-[#1E1E1E] uppercase">CHARLOTTE TILBURY</span>
            <span className="font-serif text-lg tracking-[0.2em] font-light text-[#1E1E1E] uppercase">NARS COSMETICS</span>
            <span className="font-serif text-lg tracking-[0.2em] font-light text-[#1E1E1E] uppercase">HUDA BEAUTY</span>
          </div>
        </div>

      </div>
    </section>
  );
}
