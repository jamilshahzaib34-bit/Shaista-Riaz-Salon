import React, { useState } from "react";
import { FAQs } from "../data";
import { Plus, Minus, HelpCircle } from "lucide-react";

export default function FaqSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleAccordion = (index: number) => {
    if (openIndex === index) {
      setOpenIndex(null);
    } else {
      setOpenIndex(index);
    }
  };

  return (
    <section id="faqs" className="w-full py-24 bg-[#FDFBF7] px-4 md:px-8 border-t border-gray-100">
      <div className="max-w-4xl mx-auto">
        
        {/* Header Title */}
        <div className="text-center mb-16">
          <span className="font-sans text-[11px] uppercase tracking-[0.25em] text-[#D4AF37] font-semibold block mb-3">
            YOUR QUESTIONS COMPREHENDED
          </span>
          <h2 className="font-serif text-3xl md:text-5xl text-[#1E1E1E] tracking-wide font-light uppercase">
            Frequently Asked <span className="italic block font-normal text-[#D4AF37] mt-1">Questions</span>
          </h2>
          <div className="h-[2px] w-24 bg-[#D4AF37] mx-auto mt-6"></div>
        </div>

        {/* Accordion Layout */}
        <div className="space-y-4">
          {FAQs.map((faq, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={idx}
                className="bg-[#FDFBF7] border border-[#1E1E1E]/5 hover:border-[#D4AF37]/50 transition-all duration-300"
              >
                {/* Accordion Trigger */}
                <button
                  type="button"
                  onClick={() => toggleAccordion(idx)}
                  className="w-full text-left p-6 sm:p-8 flex justify-between items-center gap-4 cursor-pointer focus:outline-none"
                  aria-expanded={isOpen}
                >
                  <span className="font-serif text-sm sm:text-base md:text-lg text-[#1E1E1E] tracking-wide font-medium">
                    {faq.question}
                  </span>
                  <span className="text-[#D4AF37] shrink-0 p-1 bg-[#F3E8E6] transition-colors duration-300">
                    {isOpen ? <Minus className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                  </span>
                </button>

                {/* Accordion Body Content */}
                <div
                  className={`overflow-hidden transition-all duration-500 ease-in-out ${
                    isOpen ? "max-h-96 opacity-100 border-t border-[#1E1E1E]/5" : "max-h-0 opacity-0"
                  }`}
                >
                  <p className="p-6 sm:p-8 font-sans text-xs sm:text-sm text-[#1E1E1E]/75 leading-relaxed font-light bg-[#F3E8E6]/25">
                    {faq.answer}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Need more block */}
        <div className="mt-16 text-center bg-[#FDFBF7] p-8 border border-[#D4AF37] max-w-2xl mx-auto">
          <p className="font-serif text-lg text-[#1E1E1E] mb-2 font-medium uppercase">
            Have a specialized bridal question?
          </p>
          <p className="font-sans text-xs text-[#1E1E1E]/70 max-w-md mx-auto mb-6">
            Get in touch with Shaista directly on WhatsApp or voice call for exclusive bridal arrangements, wedding timing custom bookings, or group discount estimates.
          </p>
          <a
            href="tel:+92518990395"
            className="inline-flex items-center gap-2 bg-[#1E1E1E] text-[#FDFBF7] hover:bg-[#D4AF37] hover:text-[#1E1E1E] px-6 py-3 font-sans text-xs uppercase tracking-widest transition-all duration-300 font-bold"
          >
            Call 051-8990395
          </a>
        </div>

      </div>
    </section>
  );
}
