import React from "react";
import { Sparkles, MapPin, Phone, Mail, Clock, Instagram, Facebook, ArrowUp } from "lucide-react";
import { BUSINESS_INFO } from "../data";

export default function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer className="w-full bg-[#1E1E1E] text-[#FDFBF7] font-sans border-t border-[#D4AF37]/30 pt-16 pb-8 px-4 md:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          
          {/* Brand Col */}
          <div className="flex flex-col gap-4 lg:col-span-1">
            <div className="flex flex-col">
              <h3 className="font-serif text-2xl tracking-wider text-[#FDFBF7] uppercase font-light leading-none mb-1">
                SHAISTA/RIAZ
              </h3>
              <span className="text-[9px] uppercase tracking-[0.25em] text-[#D4AF37] font-bold">
                Salon Bridal Studio
              </span>
            </div>
            <p className="text-xs text-[#FDFBF7]/70 leading-relaxed font-light mt-2">
              Transforming premium DHA Islamabad brides since 2018. Combining international luxury products with flawless master artist contour design techniques.
            </p>
          </div>

          {/* Quick Links Column */}
          <div className="flex flex-col gap-4">
            <h4 className="font-serif text-sm uppercase tracking-wider text-[#D4AF37] font-semibold border-b border-[#D4AF37]/10 pb-2">
              RESERVATIONS & STUDIO
            </h4>
            <div className="flex flex-col gap-2.5 text-xs">
              <a href="#about" className="text-[#FDFBF7]/75 hover:text-[#D4AF37] transition-all font-light">The Studio Concept</a>
              <a href="#services" className="text-[#FDFBF7]/75 hover:text-[#D4AF37] transition-all font-light">Core Makeovers & Aesthetics</a>
              <a href="#packages" className="text-[#FDFBF7]/75 hover:text-[#D4AF37] transition-all font-light">Bridal Ritual Slot</a>
              <a href="#reviews" className="text-[#FDFBF7]/75 hover:text-[#D4AF37] transition-all font-light">DHA Client Reviews</a>
              <a href="#faqs" className="text-[#FDFBF7]/75 hover:text-[#D4AF37] transition-all font-light">Frequently Handled FAQs</a>
            </div>
          </div>

          {/* Contact Details Column */}
          <div className="flex flex-col gap-4">
            <h4 className="font-serif text-sm uppercase tracking-wider text-[#D4AF37] font-semibold border-b border-[#D4AF37]/10 pb-2">
              STUDIO LOCATION
            </h4>
            <div className="flex flex-col gap-3 text-xs text-[#FDFBF7]/75 font-light">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                <span className="leading-relaxed font-sans">{BUSINESS_INFO.address}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <a href={`tel:${BUSINESS_INFO.phone}`} className="hover:text-[#D4AF37] transition-all">{BUSINESS_INFO.phoneDisplay}</a>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span>info@shaistariazsalon.com</span>
              </div>
            </div>
          </div>

          {/* Working Timings Grid Column */}
          <div className="flex flex-col gap-4">
            <h4 className="font-serif text-sm uppercase tracking-wider text-[#D4AF37] font-semibold border-b border-[#D4AF37]/10 pb-2">
              TIMINGS & CHANNELS
            </h4>
            <div className="flex flex-col gap-3 text-xs text-[#FDFBF7]/75 font-light">
              <div className="flex items-start gap-2">
                <Clock className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-white">Monday - Sunday</p>
                  <p className="text-[11px] text-gray-400 mt-0.5">11:00 AM - 08:00 PM</p>
                </div>
              </div>
              
              <div className="pt-2 flex items-center gap-3">
                <a
                  href={BUSINESS_INFO.instaLink}
                  aria-label="Instagram profile"
                  className="w-8 h-8 rounded-full bg-[#FDFBF7]/5 border border-[#FDFBF7]/10 hover:border-[#D4AF37] hover:text-[#D4AF37] flex items-center justify-center transition-all"
                >
                  <Instagram className="w-4 h-4" />
                </a>
                <a
                  href={BUSINESS_INFO.facebookLink}
                  aria-label="Facebook page"
                  className="w-8 h-8 rounded-full bg-[#FDFBF7]/5 border border-[#FDFBF7]/10 hover:border-[#D4AF37] hover:text-[#D4AF37] flex items-center justify-center transition-all"
                >
                  <Facebook className="w-4 h-4" />
                </a>
              </div>
            </div>
          </div>

        </div>

        <div className="h-[1px] w-full bg-[#FDFBF7]/10 mb-8"></div>

        {/* Bottom Block */}
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4 text-[11px] text-[#FDFBF7]/50 font-light">
          <div>
            <p>© {new Date().getFullYear()} SHAISTA RIAZ Salon Bridal Studio. All Rights Reserved.</p>
            <p className="text-[10px] text-[#D4AF37]/60 mt-1 font-sans">Crafted specifically for VIP DHA Clients in Islamabad.</p>
          </div>
          <button
            onClick={scrollToTop}
            className="flex items-center gap-1.5 bg-[#FDFBF7]/5 border border-[#FDFBF7]/10 hover:border-[#D4AF37] hover:text-[#D4AF37] px-3.5 py-2 transition-all text-[11px] uppercase tracking-widest font-semibold cursor-pointer"
          >
            <span>Back To Top</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </footer>
  );
}
