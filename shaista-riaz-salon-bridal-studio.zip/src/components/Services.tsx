import React, { useState } from "react";
import { Sparkles, Clock, Check, ArrowRight, Eye, Info } from "lucide-react";
import { CORE_SERVICES } from "../data";
import { ServiceCard } from "../types";

interface ServicesProps {
  onSelectService: (serviceId: string) => void;
}

export default function Services({ onSelectService }: ServicesProps) {
  const [activeTab, setActiveTab] = useState<string>("all");
  const [selectedModalService, setSelectedModalService] = useState<ServiceCard | null>(null);

  return (
    <section id="services" className="w-full py-20 px-4 md:px-8 bg-[#FDFBF7]">
      <div className="max-w-7xl mx-auto">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="font-sans text-[11px] uppercase tracking-[0.25em] text-[#D4AF37] font-semibold block mb-3">
            Pure Elegance & Artistry
          </span>
          <h2 className="font-serif text-3xl md:text-5xl text-[#1E1E1E] tracking-wide font-light uppercase">
            Core Rituals <span className="italic font-normal block mt-1 text-[#D4AF37]">and Services</span>
          </h2>
          <div className="h-[2px] w-24 bg-[#D4AF37] mx-auto mt-6"></div>
          <p className="font-sans text-xs md:text-sm text-[#1E1E1E]/70 max-w-md mx-auto mt-4 leading-relaxed font-light">
            Every service is customized to perfection, employing imported, skin-safe, ultra-glam products under high hygienic standard guidelines.
          </p>
        </div>

        {/* Categories Bar */}
        <div className="flex justify-center gap-2 sm:gap-4 mb-12 font-sans overflow-x-auto pb-2 scrollbar-none">
          {["all", "makeup", "hair", "aesthetics"].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-5 py-2.5 text-xs uppercase tracking-widest transition-all duration-300 font-medium whitespace-nowrap cursor-pointer ${
                (tab === "all" && activeTab === "all") || (tab === "makeup" && (activeTab === "bridal" || activeTab === "party" || activeTab === "makeup")) || tab === activeTab
                  ? "bg-[#1E1E1E] text-[#FDFBF7] border border-[#1E1E1E]"
                  : "bg-transparent text-[#1E1E1E]/70 border border-transparent hover:border-[#D4AF37]/40 hover:text-[#D4AF37]"
              }`}
            >
              {tab === "all" ? "View All" : tab === "makeup" ? "Makeup Art" : tab === "hair" ? "Hair Couture" : "Skin Aesthetics"}
            </button>
          ))}
        </div>

        {/* Core Services 4-Card Grid */}
        <div
          id="services-grid"
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 transition-all duration-500"
        >
          {CORE_SERVICES.filter((svc) => {
            if (activeTab === "all") return true;
            if (activeTab === "makeup") return svc.id === "bridal" || svc.id === "party";
            return svc.id === activeTab;
          }).map((service) => (
            <div
              key={service.id}
              className="group relative bg-[#FDFBF7] rounded-none overflow-hidden transition-all duration-500 hover:-translate-y-2 border border-gray-100/80 hover:border-[#D4AF37] shadow-sm hover:shadow-2xl flex flex-col justify-between"
              style={{ contentVisibility: "auto" }}
            >
              <div>
                {/* Image Frame */}
                <div className="relative h-64 overflow-hidden bg-gray-100">
                  <img
                    src={service.imageUrl}
                    alt={service.title}
                    className="w-full h-full object-cover grayscale-[20%] group-hover:grayscale-0 group-hover:scale-110 transition-all duration-700 ease-out"
                    referrerPolicy="no-referrer"
                  />
                  {/* Subtle luxurious overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1E1E1E]/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  
                  {/* Floating Price Pill */}
                  <span className="absolute top-4 right-4 bg-[#FDFBF7] text-[#1E1E1E] border border-[#D4AF37] px-3.5 py-1.5 text-xs font-mono font-semibold tracking-wider shadow-md">
                    {service.price}
                  </span>

                  {/* Interactive Eye Button */}
                  <button
                    onClick={() => setSelectedModalService(service)}
                    className="absolute bottom-4 right-4 bg-[#1E1E1E]/90 text-[#FDFBF7] p-2 hover:bg-[#D4AF37] hover:text-[#1E1E1E] transition-all cursor-pointer shadow-lg rounded-none"
                    title="View Package Details"
                  >
                    <Info className="w-4 h-4" />
                  </button>
                </div>

                {/* Body Details */}
                <div className="p-6">
                  {/* Duration and Category */}
                  <div className="flex justify-between items-center text-[10px] text-[#D4AF37] uppercase tracking-[0.2em] font-semibold mb-2 font-sans">
                    <span>{service.id === "bridal" || service.id === "party" ? "MAKEUP ARTISTRY" : service.id === "hair" ? "HAIR COUTURE" : "AESTHETICS"}</span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" /> {service.duration}
                    </span>
                  </div>

                  <h3 className="font-serif text-xl text-[#1E1E1E] font-medium tracking-wide mb-3 group-hover:text-[#D4AF37] transition-all">
                    {service.title}
                  </h3>

                  <p className="font-sans text-xs text-[#1E1E1E]/75 leading-relaxed font-light mb-4">
                    {service.description}
                  </p>

                  <div className="h-[1px] w-full bg-gray-100 my-4"></div>

                  {/* Quick Feature Highlights (Displays first 3) */}
                  <ul className="space-y-2 mb-4">
                    {service.highlights.slice(0, 3).map((hl, index) => (
                      <li key={index} className="flex items-start gap-2 text-[11px] font-sans text-[#1E1E1E]/80">
                        <Check className="w-3.5 h-3.5 text-[#D4AF37] shrink-0 mt-0.5" />
                        <span>{hl}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Card Action footer */}
              <div className="p-6 pt-0 mt-auto">
                <button
                  onClick={() => onSelectService(service.id)}
                  className="w-full flex items-center justify-center gap-2 bg-[#FDFBF7] text-[#1E1E1E] py-3 text-xs uppercase tracking-widest border border-[#D4AF37] font-semibold transition-all duration-300 hover:bg-[#1E1E1E] hover:text-[#FDFBF7] hover:border-[#1E1E1E] cursor-pointer"
                >
                  <span>Book Slot</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Informative block showing details on why clients trust Shaista */}
        <div id="about" className="mt-24 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center bg-[#F3E8E6] p-8 md:p-16 border border-[#D4AF37]/10">
          <div className="lg:col-span-5 h-80 xl:h-[400px] overflow-hidden relative shadow-lg">
            <img
              src="https://images.unsplash.com/photo-1512496015851-a90fb38ba796?auto=format&fit=crop&w=800&q=80"
              alt="Makeup Vanity Setup Inside Studio"
              className="w-full h-full object-cover grayscale-[10%]"
              referrerPolicy="no-referrer"
            />
            {/* Elegant transparent overlay */}
            <div className="absolute inset-0 bg-[#1E1E1E]/10"></div>
          </div>
          <div className="lg:col-span-7 flex flex-col justify-center">
            <span className="font-sans text-[10px] uppercase tracking-[0.25em] text-[#D4AF37] font-bold block mb-2">
              The Luxury Experience
            </span>
            <h3 className="font-serif text-2xl sm:text-3xl md:text-4xl text-[#1E1E1E] tracking-normal mb-6 font-light">
              Crafting Flawless bridal <span className="italic text-[#D4AF37]">perfection with imported premium brands</span>
            </h3>
            <p className="font-sans text-xs md:text-sm text-[#1E1E1E]/80 font-light leading-relaxed mb-6">
              Founded by master esthetician and designer Shaista Riaz, our DHA Phase II Islamabad bridal studio provides elite customized makeup styles. We prioritize high-definition cameras, ensuring that every angle of your bridal gaze is flawless under both harsh professional photography flashes and beautiful natural lighting parameters.
            </p>
            <div className="grid grid-cols-2 gap-4 text-left font-sans mb-6">
              <div className="flex gap-2">
                <div className="w-5 h-5 rounded-full bg-[#D4AF37]/10 flex items-center justify-center shrink-0 mt-0.5">
                  <Sparkles className="w-3 h-3 text-[#D4AF37]" />
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-[#1E1E1E]">Premium Imports Only</h4>
                  <p className="text-[11px] text-[#1E1E1E]/60">Dior, Charlotte Tilbury, Tom Ford & NARS</p>
                </div>
              </div>
              <div className="flex gap-2">
                <div className="w-5 h-5 rounded-full bg-[#D4AF37]/10 flex items-center justify-center shrink-0 mt-0.5">
                  <Sparkles className="w-3 h-3 text-[#D4AF37]" />
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-[#1E1E1E]">Elite Certifications</h4>
                  <p className="text-[11px] text-[#1E1E1E]/60">International micro-glow expert team</p>
                </div>
              </div>
            </div>
            <div>
              <a
                href="#booking-section"
                className="inline-flex items-center gap-1.5 font-sans font-semibold text-xs uppercase tracking-widest text-[#D4AF37] hover:text-[#1E1E1E] transition-colors"
              >
                Inquire about pre-bridal packages <ArrowRight className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>

      </div>

      {/* service details description package list view modal */}
      {selectedModalService && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#1E1E1E]/75 backdrop-blur-sm p-4 font-sans animate-fadeIn">
          <div className="bg-[#FDFBF7] border border-[#D4AF37] max-w-lg w-full p-8 relative shadow-2xl">
            {/* Close */}
            <button
              onClick={() => setSelectedModalService(null)}
              className="absolute top-4 right-4 text-[#1E1E1E] hover:text-[#D4AF37] transition-colors p-1"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>

            <span className="text-[10px] uppercase tracking-[0.25em] text-[#D4AF37] font-semibold block mb-1">
              Ritual Breakdown
            </span>
            
            <h4 className="font-serif text-2xl text-[#1E1E1E] font-medium tracking-wide mb-2 uppercase">
              {selectedModalService.title}
            </h4>

            <div className="flex justify-between items-center bg-[#F3E8E6] p-3 text-xs mb-4 font-medium">
              <span className="text-[#1E1E1E]">Price: <strong className="text-[#D4AF37] font-sans">{selectedModalService.price}</strong></span>
              <span className="text-[#1E1E1E]/75">Duration: {selectedModalService.duration}</span>
            </div>

            <p className="text-xs text-[#1E1E1E]/80 leading-relaxed mb-6 font-light">
              This customized package includes the complete range of luxury steps specified below, ensuring premium longevity, photographically supreme base layers, and beautiful setting treatments.
            </p>

            <span className="text-[11px] uppercase tracking-wider text-[#1E1E1E] font-semibold block mb-3 border-b pb-1">
              Included Premium Luxuries
            </span>

            <ul className="space-y-2.5 mb-6">
              {selectedModalService.highlights.map((item, id) => (
                <li key={id} className="flex items-start gap-2.5 text-xs text-[#1E1E1E]/90 leading-relaxed">
                  <Check className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>

            <button
              onClick={() => {
                const id = selectedModalService.id;
                setSelectedModalService(null);
                onSelectService(id);
              }}
              className="w-full bg-[#1E1E1E] text-white py-3 font-sans font-bold uppercase tracking-widest text-xs hover:bg-[#D4AF37] hover:text-[#1E1E1E] transition-all decoration-0 cursor-pointer"
            >
              Book {selectedModalService.title}
            </button>
          </div>
        </div>
      )}
    </section>
  );
}
