import React, { useState, useEffect } from "react";
import { Sparkles, Phone, Clock, Menu, X, Calendar } from "lucide-react";
import { BUSINESS_INFO } from "../data";

interface NavbarProps {
  onBookClick: () => void;
}

export default function Navbar({ onBookClick }: NavbarProps) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 30) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <>
      {/* Top Banner with hours & contact info */}
      <div id="top-bar" className="w-full bg-[#1E1E1E] text-[#FDFBF7] text-xs py-2 px-4 border-b border-[#D4AF37]/20">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-2">
          <div className="flex items-center gap-4 font-sans text-[11px] uppercase tracking-widest text-[#FDFBF7]/85">
            <span className="flex items-center gap-1.5">
              <Clock className="w-3 h-3 text-[#D4AF37]" />
              {BUSINESS_INFO.hours}
            </span>
          </div>
          <div className="flex items-center gap-4 font-sans text-[11px] uppercase tracking-widest">
            <a href={`tel:${BUSINESS_INFO.phone}`} className="flex items-center gap-1.5 hover:text-[#D4AF37] transition-colors">
              <Phone className="w-3 h-3 text-[#D4AF37]" />
              {BUSINESS_INFO.phoneDisplay}
            </a>
            <span className="h-3 w-[1px] bg-[#FDFBF7]/20 hidden sm:inline"></span>
            <span className="text-[#D4AF37] font-semibold">DHA Phase II Islamabad</span>
          </div>
        </div>
      </div>

      {/* Main Luxury Sticky Header */}
      <nav
        id="main-navigation"
        className={`sticky top-0 z-50 w-full transition-all duration-300 ${
          scrolled
            ? "bg-[#FDFBF7]/95 backdrop-blur-md shadow-md py-3 border-b border-[#D4AF37]/10"
            : "bg-[#FDFBF7] py-5"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 md:px-8 flex justify-between items-center">
          {/* Brand/Logo Design */}
          <a href="#" className="flex flex-col select-none group">
            <h1 className="font-serif text-xl sm:text-2xl md:text-3xl tracking-wider text-[#1E1E1E] font-medium leading-none mb-1">
              SHAISTA RIAZ
            </h1>
            <p className="font-sans text-[8px] sm:text-[10px] uppercase tracking-[0.25em] text-[#D4AF37] font-semibold leading-none">
              Salon Bridal Studio
            </p>
          </a>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-8 font-sans">
            <a href="#about" className="text-sm font-medium text-[#1E1E1E]/80 hover:text-[#D4AF37] transition-all tracking-wider uppercase text-[12px]">
              The Studio
            </a>
            <a href="#services" className="text-sm font-medium text-[#1E1E1E]/80 hover:text-[#D4AF37] transition-all tracking-wider uppercase text-[12px]">
              Core Services
            </a>
            <a href="#packages" className="text-sm font-medium text-[#1E1E1E]/80 hover:text-[#D4AF37] transition-all tracking-wider uppercase text-[12px]">
              Signature Packages
            </a>
            <a href="#reviews" className="text-sm font-medium text-[#1E1E1E]/80 hover:text-[#D4AF37] transition-all tracking-wider uppercase text-[12px]">
              Accolades
            </a>
            <a href="#faqs" className="text-sm font-medium text-[#1E1E1E]/80 hover:text-[#D4AF37] transition-all tracking-wider uppercase text-[12px]">
              FAQs
            </a>
          </div>

          {/* CTA Button */}
          <div className="hidden md:flex items-center gap-4">
            <button
              onClick={onBookClick}
              id="nav-booking-cta"
              className="group flex items-center gap-2 bg-[#1E1E1E] text-[#FDFBF7] px-6 py-2.5 rounded-none font-sans text-xs uppercase tracking-widest border border-[#1E1E1E] hover:bg-[#FDFBF7] hover:text-[#1E1E1E] hover:border-[#D4AF37] active:scale-[0.98] transition-all duration-300 cursor-pointer"
            >
              <Calendar className="w-4 h-4 text-[#D4AF37] group-hover:text-[#D4AF37]" />
              Book Ritual
            </button>
          </div>

          {/* Mobile Menu Toggle Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            id="mobile-menu-trigger"
            className="lg:hidden p-2 text-[#1E1E1E] hover:text-[#D4AF37] transition-colors"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Navigation Dropdown */}
        {mobileMenuOpen && (
          <div
            id="mobile-dropdown-menu"
            className="lg:hidden absolute top-full left-0 w-full bg-[#FDFBF7] border-b border-[#D4AF37]/20 shadow-xl overflow-hidden py-6 px-4 flex flex-col gap-4 animate-fadeIn transition-all duration-300 font-sans"
          >
            <a
              href="#about"
              onClick={() => setMobileMenuOpen(false)}
              className="text-base font-semibold text-[#1E1E1E] py-2 border-b border-gray-100 uppercase tracking-widest text-[12px]"
            >
              The Studio
            </a>
            <a
              href="#services"
              onClick={() => setMobileMenuOpen(false)}
              className="text-base font-semibold text-[#1E1E1E] py-2 border-b border-gray-100 uppercase tracking-widest text-[12px]"
            >
              Core Services
            </a>
            <a
              href="#packages"
              onClick={() => setMobileMenuOpen(false)}
              className="text-base font-semibold text-[#1E1E1E] py-2 border-b border-gray-100 uppercase tracking-widest text-[12px]"
            >
              Signature Packages
            </a>
            <a
              href="#reviews"
              onClick={() => setMobileMenuOpen(false)}
              className="text-base font-semibold text-[#1E1E1E] py-2 border-b border-gray-100 uppercase tracking-widest text-[12px]"
            >
              Accolades
            </a>
            <a
              href="#faqs"
              onClick={() => setMobileMenuOpen(false)}
              className="text-base font-semibold text-[#1E1E1E] py-2 border-b border-gray-100 uppercase tracking-widest text-[12px]"
            >
              FAQs
            </a>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onBookClick();
              }}
              id="mobile-nav-booking-cta"
              className="w-full flex items-center justify-center gap-2 bg-[#D4AF37] text-[#1E1E1E] font-bold uppercase tracking-widest text-xs py-3 rounded-none mt-2 shadow-md hover:bg-[#1E1E1E] hover:text-[#FDFBF7] hover:border-[#D4AF37] transition-all duration-300"
            >
              <Calendar className="w-4 h-4" />
              Book Appointment
            </button>
          </div>
        )}
      </nav>
    </>
  );
}
